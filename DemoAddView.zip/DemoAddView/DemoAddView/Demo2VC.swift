//
//  Demo2VC.swift
//  DemoAddView
//
//  Created by Hoàng Hải on 11/11/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class Demo2VC: UIViewController {

    @IBOutlet weak var headerView: DemoView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        headerView.headerLabel.text = "ThirdVC"
        headerView.titleLabel.text = "Ahihi \n ---- Ahoho ----"
    }
    
}

